#ifndef ENEMY_H_INCLUDED
#define ENEMY_H_INCLUDED
#define LbirdsNumber 5
#define BbirdsNumber 2

struct LittleBird
{
	int LbirdX;
	int LbirdY;
	int LbirdIndex;
	bool LbirdShow;
	int BbirdX;
	int BbirdY;
	int BbirdIndex;
	bool BbirdShow;
};

LittleBird enemy[LbirdsNumber];
LittleBird enemy2[BbirdsNumber];

/////bird1 and 2 move ////

void LbirdMove()
{
	for(int i=0;i<LbirdsNumber;i++)
	{
		if(enemy[i].LbirdShow)
		{
			iShowImage(enemy[i].LbirdX,enemy[i].LbirdY,80,120,Lenemy[enemy[i].LbirdIndex]);
		}
	}

}
void BbirdMove()
{
	for(int i=0;i<BbirdsNumber;i++)
	{
		if(enemy2[i].BbirdShow)
		{
			iShowImage(enemy2[i].BbirdX,enemy2[i].BbirdY,200,320,Benemy[enemy2[i].BbirdIndex]);
		}
	}

}

//// Fire ////

struct Fire
{
	int x;
	int y;

	bool show;
	

}fire[100000],Bfire[100000];

void fireshow()
{
	for(int i=0; i<Firecount ;i++)
	{
		if(fire[i].show=true)
		{
			iShowBMP2(fire[i].x,fire[i].y,"images\\fire1.bmp",0);
		}


	}
	for(int i=0; i<Bfirecount ;i++)
	{
		if(Bfire[i].show=true)
		{

			
			iShowImage(Bfire[i].x,Bfire[i].y,330,220,bluefire);
		}


	}
	
}

int Boss_x=800, Boss_y=0;
int Lx=0, Ly=6;

void bossmovement() {
	//Boss_x += Lx;
	Boss_y += Ly;

	if (Boss_x >= 0 || Boss_x <= 0)
		Lx = -Lx;
	if (Boss_y >= 380 || Boss_y <= 0)
		Ly = -Ly;


		ay -=5;
		if(ay<=0)
		{
			ay=750;
		}
		zy -=5;
		if(zy<=0)
		{
			zy=750;
		}
		cy -=5;
		if(cy<=0)
		{
			cy=750;
		}



		
}


////// no rendering ////









#endif
