#include "iGraphics.h"
#include "bitmap_loader.h"
#include "Variables.h"
#include "Enemy.h"
#define JumpLimit 200
#define screenWidth 1360
#define screenHeight 750
//variables declaration
int Menu,Background,Back,Ins,Hero,Score,About,Credits,GameOver,mx,my;
char str[100], str2[100], strshow1[100], strshow2[100], strshow3[100], strshow4[100], strshow5[100];
int len;
int mode;
int flag = 0;


//#include "movement.h"

bool jump =false;
bool jumpUp=false;

int NatsuCoordinateJump= 0;

int standcounter=0;
int eee;
int enemyPassedCounter=0;
int by= 9;
int bb1,bb2;
struct player
{
	int score;
	char name[250];
}play[100],t;

void enemyMovement1()//1st enemy movement
{
	Lbx1-=dx;
	if(Lbx1<=0)
	{
		//enemyPassedCounter++;
		Lby1=screenWidth;
	}

}
void enemyMovement2()//2nd enemy movement
{
	Lbx2-=dx;
	if(Lbx2<=0)
	{
		//enemyPassedCounter++;
		Lbx2=screenWidth;

	}
}

void enemyMovement3()//2nd enemy movement
{

	Lbx3-=dx;
	if(Lbx3<=0)
	{
		//enemyPassedCounter++;
		Lbx3=screenWidth;

	}
}
void enemyMovement4()//4th enemy movement
{

	Lbx4-=dx;
	if(Lbx4<=0)
	{
		//enemyPassedCounter++;
		Lbx4=screenWidth;

	}
}

void enemyMovement5()//5th enemy movement
{

	Lbx5-=dx;
	if(Lbx5<=0)
	{
		//enemyPassedCounter++;
		Lbx5=screenWidth;

	}
}
void enemyMovement6()//6th enemy movement
{

	Lbx6-=dx;
	if(Lbx6<=0)
	{
		//enemyPassedCounter++;
		Lbx6=screenWidth;

	}
}
void enemyMovement7()//6th enemy movement
{

	Bbx1-=dx;
	if(Bbx1<=0)
	{
		//enemyPassedCounter++;
		Bbx1=screenWidth;

	}
}
void enemyMovement8()//6th enemy movement
{

	Bbx2-=dx;
	if(Bbx2<=0)
	{
		//enemyPassedCounter++;
		Bbx2=screenWidth;

	}
}
void fireMovement1()
{

	bx1-=by;
	if(bx1<=0)
	{
		bx1=Bbx1;

	}
	bx2-=by;
	if(bx2<=0)
	{
		bx2=Bbx2;

	}
}
void fireMovement2()
{

	bx2-=by;
	if(bx2<=0)
	{
		bx2=Bbx2;

	}
}

void playermovement()
{
	if(help)
	{
		if(jump)
		{
			if(jumpUp)
			{
			iShowBMP2(NatsuX,NatsuY+NatsuCoordinateJump,NatsuJump[ImageIndex],0);
			}
			else
			{
			iShowBMP2(NatsuX,NatsuY+NatsuCoordinateJump,NatsuJump[0],0);
			}

		}
		else
		{	
			if(!NowStand)
			{
			iShowBMP2(NatsuX,NatsuY,NatsuForward[ImageIndex],0);
			standcounter++;
			if(standcounter>=1000000000000)
			{
			standcounter=-1000;
			ImageIndex = 0;
			NowStand = true;
			}

			}
			else
			{
			iShowBMP2(NatsuX,NatsuY,NatsuForward[0],0);
		
	
			}

		}
	}

	 if(Smash)
	{
		
	
		iShowImage(NatsuX,NatsuY,200,310,smash);
		
			
		

		
	
	}
}
void collision()
{
	for(int i=0;i<100;i++)
	{
	if((fire[i].x +20> Lbx1 && fire[i].x < Lbx1+80) && (fire[i].y+ 61>Lby1 && fire[i].y <Lby1 +120))
	{
		
		Lbx1=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
		
	

	}
	else if((fire[i].x +20> Lbx2 && fire[i].x < Lbx2+80) && (fire[i].y+ 61>Lby2 && fire[i].y <Lby2 +120))
	{
		Lbx2=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
	}
	else if((fire[i].x +20> Lbx3 && fire[i].x < Lbx3+80) && (fire[i].y+ 61>Lby3 && fire[i].y <Lby3 +120))
	{
		Lbx3=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;

	}
	else if((fire[i].x +20> Lbx4 && fire[i].x < Lbx4+80) && (fire[i].y+ 61>Lby4 && fire[i].y <Lby4 +120))
	{
		Lbx4=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
	}
	else if((fire[i].x +20> Lbx5 && fire[i].x < Lbx5+80) && (fire[i].y+ 61>Lby5 && fire[i].y <Lby5 +120))
	{
		Lbx5=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
	}
	else if((fire[i].x +20> Lbx6 && fire[i].x < Lbx6+80) && (fire[i].y+ 61>Lby6 && fire[i].y <Lby6 +120))
	{
		Lbx6=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
	}
	}
	
	for(int i=0;i<100;i++)
	{
	if((Bfire[i].x +130 > Bbx1 && Bfire[i].x < Bbx1 +100) && (Bfire[i].y+ 120 >Bby1 && Bfire[i].y <Bby1 +120))
	{
		
		Bbx1=screenWidth;
		Bfire[i].x=1500;
		Bfire[i].y=1500;
	

	}
	else if((Bfire[i].x +130 > Bbx2 && Bfire[i].x < Bbx2 +100) && (Bfire[i].y+ 120 >Bby2 && Bfire[i].y <Bby2 +120))
	{
		Bbx2=screenWidth;
		Bfire[i].x=1500;
		Bfire[i].y=1500;
	}
	}
	
	if(NatsuX <=0)
	{
		NatsuX=0;
	}

	if(NatsuX >= screenWidth-150)
	{
		NatsuX=screenWidth-150;
	}

	
	if(NatsuX+ 100>Bbx1 && NatsuX<Bbx1+180 && NatsuY +210 >Bby1 && NatsuY < Bby1+320)
	{
			NatsuX=0;
			//enemy2[i].BbirdShow=true;

	}
	else if(NatsuX+ 100>Bbx2 && NatsuX<Bbx2+180 && NatsuY +210 >Bby2 && NatsuY < Bby2+320)
	{
		NatsuX=0;
	}

	if(NatsuX+ 50>bx1 && NatsuX<bx1+80 && NatsuY +110 >by1 && NatsuY < by1+120)
	{
		NatsuX=0;
	}
	else if(NatsuX+ 50>bx1 && NatsuX<bx1+80 && NatsuY +110 >by1 && NatsuY < by1+120)
	{
		NatsuX=0;
	}
}

void drawTextBox()
{
	
	iSetColor(220, 20, 60);
	iText(530, 585, "Input your name: ");
	iRectangle(530, 550, 250, 30);

}
void drawTextBox2()
{
		iSetColor(255, 255, 255);
		iText(530, 535, "Input your Score: ");
	    iRectangle(530, 500, 250, 30);

}
//iDraw function
void iDraw()
{
	iClear();
	//Menu informations
    if(flag == 0){
	iShowImage(0, 0, screenWidth, screenHeight, Menu);
	}
	else if (flag == 1)
	{
		iShowImage(0, 0, screenWidth, screenHeight, Background);

		LbirdMove();
		BbirdMove();
		fireshow();
		//iShowImage(10, 10, 150, 170, Hero);
		playermovement();
		collision();

		iShowImage(Lbx1,Lby1,80,120,LiLB1);//enemy1
		iShowImage(Lbx2,Lby2,80,120,LiLB1);//enemy2
		
		iShowImage(Lbx3,Lby3,80,120,LiLB1);//enemy3
		iShowImage(Lbx4,Lby4,80,120,LiLB1);//enemy4

		iShowImage(Lbx5,Lby5,80,120,LiLB1);//enemy5
		iShowImage(Lbx6,Lby6,80,120,LiLB1);//enemy6
	
		iShowImage(Bbx1,Bby1,320,220,BigB1);
		iShowImage(bx1-20,by1+20,50,50,bigfire);


		iShowImage(Bbx2,Bby2,320,220,BigB1);
		iShowImage(bx2-20,by2+20,50,50,bigfire);

		iShowImage(1100, 50, 150, 150, Back);
	}
	else if (flag == 2)
	{ 
		iShowImage(0, 0, screenWidth, screenHeight, Ins);
		iShowImage(1100, 50, 150, 150, Back);
	}
	else if (flag == 3)
	{ 
		//reading scores from file and show them on the scorecard screen
		iShowImage(0, 0, screenWidth, screenHeight, Score);
		iShowImage(1100, 50, 150, 150, Back);
		sprintf(strshow1,"1.\t %s\t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t%d",play[0].name,play[0].score);
		sprintf(strshow2,"2.\t %s\t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t%d",play[1].name,play[1].score);
		sprintf(strshow3,"3.\t %s\t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t%d",play[2].name,play[2].score);
		sprintf(strshow4,"4.\t %s\t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t%d",play[3].name,play[3].score);
		sprintf(strshow5,"5.\t %s\t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t%d",play[4].name,play[4].score);
		iSetColor(255, 255, 255);
		iText(505,560,strshow1,GLUT_BITMAP_HELVETICA_18);
		iText(505,540,strshow2,GLUT_BITMAP_HELVETICA_18);
		iText(505,520,strshow3,GLUT_BITMAP_HELVETICA_18);	
		iText(505,500,strshow4,GLUT_BITMAP_HELVETICA_18);	
		iText(505,480,strshow5,GLUT_BITMAP_HELVETICA_18);	
		
	}
	else if (flag == 4)
	{ 
		iShowImage(0, 0, screenWidth, screenHeight, About);
		iShowImage(1100, 50, 150, 150, Back);
	}
	else if (flag == 5)
	{ 
		iShowImage(0, 0, screenWidth, screenHeight, Credits);
		iShowImage(1100, 50, 150, 150, Back);
	}
	else if (flag == 6)
	{ 
		iShowImage(0, 0, screenWidth, screenHeight, GameOver);
		iShowImage(1100, 50, 150, 150, Back);
		drawTextBox();
	if(mode == 1)
	{
		iSetColor(255, 255, 255);
		iText(531, 558, str);
	}
		drawTextBox2();
		if(mode == 2)
	{
		iSetColor(255, 255, 255);
		iText(531, 505, str);
	}
	}
	else if (flag == 7)
	{
		exit(0);
	}
}

void iPassiveMouse(int x, int y)
{
;
}

void iMouseMove(int mx, int my)
{

	;

}
void iMouse(int button, int state, int mx, int my)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		printf("\n%d \t %d\n", mx, my);
		while(flag==0)
		{
		//Start button actions
		if(mx > 66 && mx < 308 && my > 310 && my < 354)
		{
			flag = 1;
		
	    }
		//Informations button actions
		else if( mx > 66 && mx < 308 && my > 255 &&  my < 297)
		{
			flag = 2;

		}
		//Score button actions
		else if( mx > 66 && mx < 308 && my > 200 &&  my < 238)
		{
			flag = 3;
		}
		//About button actions
		else if( mx > 66 && mx < 308 && my > 144 &&  my < 185)
		{
			flag = 4;
		}
		//Credits button actions
		else if( mx > 66 && mx < 308 && my > 91 &&  my < 133)
		{
			flag = 5;
		}
		//Exit button actions
		else if( mx > 66 && mx < 308 && my > 33 &&  my < 76)
		{
			flag = 7;
		}
		}
		//Back button actions
		
		
	if( mx > 1110 && mx < 1242 && my > 91 &&  my < 162)
		{
			flag = 0;
		}
		
		//clicking the left mouse button to the name taking box to input the name
	 if(mx > 529 && mx < 778 && my > 554 && my < 580)
		{
			mode = 1;
		}
		else if(mx > 529 && mx < 778 && my > 501 && my < 530)
		{
			mode = 2;
		}

		
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
	
	
	}
}
}
void iKeyboard(unsigned char key)
{
	FILE *fp=fopen("data.txt","a");
	int i;
	if(mode == 1)
	{
        if(key == '\r')
		{
			mode = 0;
			strcpy(str2, str);
			fprintf(fp,"%s\t\t", str2);
			for(i = 0; i < len; i++)
				str[i] = 0;
			len = 0;
		}
		else
		{
			str[len] = key;
			len++;
		}
	}
	FILE *fp2=fopen("data.txt","a");
	if(mode == 2)
		
	{
        if(key == '\r')
		{
			mode = 0;
			strcpy(str2, str);
			fprintf(fp2,"%s\n", str2);
			for(i = 0; i < len; i++)
				str[i] = 0;
			len = 0;
		}
		else
		{
			str[len] = key;
			len++;
		}
	}

	if (key == 'v')
	{

		if(ImageIndex >=5 )
		{
			ImageIndex++;
			ImageIndex=0;
		}
		if(ImageIndex ==5 )
		{
			ImageIndex =5;
			if(ImageIndex >=0 )
		{
			ImageIndex--;
			
		}
		}
		NowFire =true;
		
	}

	if (key == ' ')
	{
		if(!jump)
		{
			jump=true;
			jumpUp=true;
		}
		help=true;
		Smash=false;
	}

	if (key == 'a')
	{
		NatsuX -=10;
			ImageIndex++;

		if(ImageIndex >=6 )
			ImageIndex=0;

		

		NowStand = false;
		help=true;
		Smash=false;
	}

	if (key == 'd')
	{
			/// going right ////////
			NatsuX +=10;
			ImageIndex++;

		if(ImageIndex >=6 )
			ImageIndex=0;
		

		NowStand = false;
		help=true;
		Smash=false;
	}

	///// using power ///

	if (key == 'f')
	{
		if(Firecount <100)
		{
			Firecount++;

		}
		else if(Firecount == 100)
		{
			Firecount=0;
		}

		fire[Firecount-1].show =true;
		fire[Firecount-1].x=NatsuX+57;
		fire[Firecount-1].y=NatsuY+127;
		Smash=false;
		help=true;

	}

	if(key=='c'&& keypressed)
	{
		if(Bfirecount <6)
		{
			Bfirecount ++;
			

		}
		else if(Bfirecount == 6)
		{
				Bfire[Bfirecount-1].show =false;
				keypressed=0;
		}
		

		Smash=true;
		help=false;
		NowStand=true;
		jump=true;
		Bfire[Bfirecount-1].show =true;
		Bfire[Bfirecount-1].x=NatsuX+50;
		Bfire[Bfirecount-1].y=NatsuY+screenHeight ;

	}
	
	}



void iSpecialKeyboard(unsigned char key)
{
  while (flag == 1){
   
	if (key == GLUT_KEY_END)
	{	
	
	{
		flag = 6;
		}
	}
  } 
}


////// functions /////

void Natsujump()
{
	if(jump)
	{
		if(jumpUp)
		{
			NatsuCoordinateJump +=5;
			if(NatsuCoordinateJump >=JumpLimit)
			{
				jumpUp =false;
			}
		}
		else
		{
			NatsuCoordinateJump -=5;
			if(NatsuCoordinateJump <0 )
			{
				jump =false;
			NatsuCoordinateJump =0;
			}

		}
	}
	

	
}

////// LBird moving /////

void EnemyBirdSpeed()
{
	for(int i=0;i<LbirdsNumber;i++)
	{
		enemy[i].LbirdX -=10;
		if(enemy[i].LbirdX <=0 )
		{
			enemy[i].LbirdX = screenWidth + rand()%800;
			//enemy[i].LbirdShow = true;
		}
		enemy[i].LbirdIndex++;
		if(enemy[i].LbirdIndex >=3)
		{
			enemy[i].LbirdIndex = 0;
		}
	}
	
}

//// BBird moving ////

void EnemyBird2Speed()
{
	for(int i=0;i<BbirdsNumber;i++)
	{
		enemy2[i].BbirdX -=10;
		if(enemy2[i].BbirdX <=0 )
		{
			enemy2[i].BbirdX = screenWidth + rand()%1000;
			//enemy2[i].BbirdShow = true;
		}
		enemy2[i].BbirdIndex++;
		if(enemy2[i].BbirdIndex >=3)
		{
			enemy2[i].BbirdIndex = 0;
		}
	}


}



void setLBird()
{
	for(int i =0;i<LbirdsNumber;i++)
	{
		enemy[i].LbirdX = screenWidth + rand()%800;
		enemy[i].LbirdY = 200 + rand()%500;
		enemy[i].LbirdIndex = rand()%10;
		enemy[i].LbirdShow = true;

	}
}

void setBBird()
{
	for(int i =0;i<BbirdsNumber;i++)
	{
		enemy2[i].BbirdX = screenWidth + rand()%1000;
		enemy2[i].BbirdY = 30;
		enemy2[i].BbirdIndex = rand()%10;
		enemy2[i].BbirdShow = true;

	}
}
//////Fire /////
void FireThrow()
{
	for(int i=0;i<Firecount;i++)
	{
		if(fire[i].show)
		{
			fire[i].x +=20;
			/////sdsdsds///
			fire[i].y +=10;

		}
		
		if(fire[i].x > screenWidth)
		{
			fire[i].show =false;
		}
		
	}
	for(int i=0;i<Bfirecount;i++)
	{
		if(Bfire[i].show)
		{
			Bfire[i].y -=20;
		}
		if(Bfire[i].x > screenHeight)
		{
			Bfire[i].show =false;
		}
	}


}

//imain function
int main()
{
	FILE *fp=fopen("data.txt","r");
	int i,j;
	//sorting
			for(i = 0; i <10; i++)
			{
				fscanf(fp,"%s %d",play[i].name,&play[i].score); 
			}
			len = 0;
			for(i=0;i<10;i++)
			{
				for(j=0;j<9;j++)
				{
					if(play[j].score<play[j+1].score)
					{
						t=play[j];
						play[j]=play[j+1];
						play[j+1]=t;
						
						
			}
					
		}
			
	}
			for(i=0;i<play[i].score;i++)
    {
        printf("%s\t\t\t%d\n",play[i].name,play[i].score);
    }



	setLBird();
	setBBird();

	iSetTimer(12,Natsujump);
	//iSetTimer(80,EnemyBirdSpeed);
	//iSetTimer(110,EnemyBird2Speed);
	iSetTimer(20,FireThrow);
	//iSetTimer(20,setBBird);

	/// enemy movement timing ////
	LB1 = iSetTimer(58,enemyMovement1);
	LB4 = iSetTimer(50,enemyMovement4);
	//LB6= iSetTimer(60,enemyMovement6);
	LB5 = iSetTimer(70,enemyMovement5);
	LB2 = iSetTimer(47,enemyMovement2);
	LB3 =iSetTimer(85,enemyMovement3);
	BB1=iSetTimer(70,enemyMovement7);
	BB2=iSetTimer(85,enemyMovement8);
	////fire movement ////
	bb1 = iSetTimer(70,fireMovement1);
	//bb2 = iSetTimer(30,fireMovement2);

	iInitialize(screenWidth, screenHeight, "The Last FireBender");
	//Images implimantations
	Menu = iLoadImage("images\\1Menunew.png");
	Background = iLoadImage("images\\1Background.jpg");
	Back = iLoadImage("images\\Back.png");
	Ins = iLoadImage("images\\3Instructions.png");
	Score = iLoadImage("images\\Scoreboard.png");
	Hero = iLoadImage("images\\0.png");
	About = iLoadImage("images\\About.png");
	Credits = iLoadImage("images\\Credits.png");
	GameOver = iLoadImage("images\\Gameover.jpg");

	imageload();

	iStart();

	return 0;
}

