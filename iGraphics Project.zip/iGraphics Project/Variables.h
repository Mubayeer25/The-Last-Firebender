#ifndef VARIABLES_H_INCLUDED
#define VARIABLES_H_INCLUDED

int Xaxis,Yaxis;
int x,y;
int NatsuX=0,NatsuY=50;
int NatsuFire[15],NatsuDef[15],NatsuKick[15],NatsuPunch[15],Lenemy[3];
int JumpY = 100;
int ImageIndex=0;
int background1;
char NatsuForward[6][27]={"images\\Natsu\\Forward\\0.bmp","images\\Natsu\\Forward\\1.bmp","images\\Natsu\\Forward\\2.bmp","images\\Natsu\\Forward\\3.bmp","images\\Natsu\\Forward\\4.bmp","images\\Natsu\\Forward\\5.bmp"};
char NatsuJump[6][27]={"images\\Natsu\\Jump\\0.bmp","images\\Natsu\\Jump\\1.bmp","images\\Natsu\\Jump\\2.bmp","images\\Natsu\\Jump\\3.bmp","images\\Natsu\\Jump\\3.bmp","images\\Natsu\\Jump\\4.bmp"};
int Benemy[4];
int smash;
int Bbfire,bluefire;
int firestop;
int dude=0,boropakhi;
int f1,f2,f3;
/////////// Control of Natsu //////////////////

bool NowStand = true;
bool NowForward = false;
bool NowBackward = false;
bool NowKick = false;
bool NowPunch = false;
bool Smash;
bool help;
int ax=300,ay=750,zy=750,zx=630,cx=860,cy=750;

//int kpdx=395,kpdy=10;
int Firecount=0;
int Bfirecount=0;

bool NowFire = false;

int keypressed = 1;
//
//
bool NowDefence = false;
bool NatsuDefence = false;

//char Fire[1][20]={"images\\fire1.bmp"};

////// new birds axis ////
int LiLB1,BigB1,bossmove;


int Lby1=500,Lby2=350,Lby3=400,Lby4=600,Lby5=450,Lby6=550;
int Bby1=50,Bby2=50;
int Bbx1=1360,Bbx2=2000;


int Lbx1=1360, Lbx2=1400, Lbx3=1600, Lbx4=1500, Lbx5=1396, Lbx6=1800;


int by1=50,by2=50;


int bx1=1360,bx2=2000;

int dx=5;

int LB1,LB2,LB3,LB4,LB5,LB6,BB1,BB2;
int bigfire;

int l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;

//////////// Natsu images /////////

void imageload(){

		////forward//	

	

		///jump//
		
		smash=iLoadImage("images\\Natsu\\smash.png");
		

		//punch//


		NatsuPunch[0]=iLoadImage("images\\Natsu\\Punch\\0.png");
		NatsuPunch[1]=iLoadImage("images\\Natsu\\Punch\\1.png");
		NatsuPunch[2]=iLoadImage("images\\Natsu\\Punch\\2.png");
		NatsuPunch[3]=iLoadImage("images\\Natsu\\Punch\\3.png");
		NatsuPunch[4]=iLoadImage("images\\Natsu\\Punch\\4.png");
		NatsuPunch[5]=iLoadImage("images\\Natsu\\Punch\\5.png");
		NatsuPunch[6]=iLoadImage("images\\Natsu\\Punch\\5.png");
		NatsuPunch[7]=iLoadImage("images\\Natsu\\Punch\\4.png");
		NatsuPunch[8]=iLoadImage("images\\Natsu\\Punch\\3.png");
		NatsuPunch[9]=iLoadImage("images\\Natsu\\Punch\\2.png");
		NatsuPunch[10]=iLoadImage("images\\Natsu\\Punch\\1.png");
		NatsuPunch[11]=iLoadImage("images\\Natsu\\Punch\\0.png");


		//kick//

		NatsuKick[0]=iLoadImage("images\\Natsu\\Kick\\0.png");
		NatsuKick[1]=iLoadImage("images\\Natsu\\Kick\\1.png");
		NatsuKick[2]=iLoadImage("images\\Natsu\\Kick\\2.png");
		NatsuKick[3]=iLoadImage("images\\Natsu\\Kick\\2.png");

		//fire//

		Bbfire=iLoadImage("images\\Natsu\\Fire\\fireball.png");
		bluefire=iLoadImage("images\\Natsu\\Fire\\bluefire.png");

		/*
		NatsuFire[0]=iLoadImage("images\\Natsu\\Fire\\0.png");
		NatsuFire[1]=iLoadImage("images\\Natsu\\Fire\\1.png");
		NatsuFire[2]=iLoadImage("images\\Natsu\\Fire\\2.png");
		NatsuFire[3]=iLoadImage("images\\Natsu\\Fire\\3.png");
		NatsuFire[4]=iLoadImage("images\\Natsu\\Fire\\4.png");
		NatsuFire[5]=iLoadImage("images\\Natsu\\Fire\\5.png");
		NatsuFire[6]=iLoadImage("images\\Natsu\\Fire\\6.png");
		NatsuFire[7]=iLoadImage("images\\Natsu\\Fire\\7.png");
		NatsuFire[8]=iLoadImage("images\\Natsu\\Fire\\8.png");
		NatsuFire[9]=iLoadImage("images\\Natsu\\Fire\\9.png");
		NatsuFire[10]=iLoadImage("images\\Natsu\\Fire\\10.png");
		*/

		background1=iLoadImage("images\\Background\\1.jpg");


		///// Enemy //////
		Lenemy[0]=iLoadImage("images\\Enemy\\LBird\\0.png");
		Lenemy[1]=iLoadImage("images\\Enemy\\LBird\\1.png");
		Lenemy[2]=iLoadImage("images\\Enemy\\LBird\\2.png");
		Lenemy[3]=iLoadImage("images\\Enemy\\LBird\\3.png");

		Benemy[0]=iLoadImage("images\\Enemy\\0-removebg.png");
		Benemy[1]=iLoadImage("images\\Enemy\\1-removebg.png");
		Benemy[2]=iLoadImage("images\\Enemy\\2-removebg.png");
		Benemy[3]=iLoadImage("images\\Enemy\\3-removebg.png");
		Benemy[4]=iLoadImage("images\\Enemy\\4-removebg.png");
		


		LiLB1=iLoadImage("images\\Enemy\\LBird\\2.png");
		BigB1=iLoadImage("images\\Enemy\\1-removebg.png");
		//LiLB2=iLoadImage("images\\Enemy\\LBird\\2.png");
		//LiLB3=iLoadImage("images\\Enemy\\LBird\\2.png");
		//LiLB4=iLoadImage("images\\Enemy\\LBird\\2.png");
		///LiLB5=iLoadImage("images\\Enemy\\LBird\\2.png");
		//LiLB6=iLoadImage("images\\Enemy\\LBird\\2.png");
		bigfire=iLoadImage("images\\Natsu\\Fire\\bluefire.png");


		l1=iLoadImage("images\\Natsu\\Fire\\bluefire.png");
		l2=iLoadImage("images\\Natsu\\Fire\\bluefire.png");
		l3=iLoadImage("images\\Natsu\\Fire\\bluefire.png");
		l4=iLoadImage("images\\Natsu\\Fire\\bluefire.png");
		l5=iLoadImage("images\\Natsu\\Fire\\bluefire.png");
		l6=iLoadImage("images\\Natsu\\Fire\\bluefire.png");
		l7=iLoadImage("images\\Natsu\\Fire\\bluefire.png");
		l8=iLoadImage("images\\Natsu\\Fire\\bluefire.png");
		l9=iLoadImage("images\\Natsu\\Fire\\bluefire.png");
		l10=iLoadImage("images\\Natsu\\Fire\\bluefire.png");



		f1=iLoadImage("images\\Natsu\\Fire\\fireball.png");
		f2=iLoadImage("images\\Natsu\\Fire\\fireball.png");
		f3=iLoadImage("images\\Natsu\\Fire\\fireball.png");



}


#endif