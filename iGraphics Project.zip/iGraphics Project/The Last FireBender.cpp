#include "iGraphics.h"
#include "bitmap_loader.h"
#include "Variables.h"
#include "Enemy.h"
#define JumpLimit 200
#define screenWidth 1360
#define screenHeight 750
//variables declaration
int Menu,Background,Back,Ins,Hero,Score,About,Credits,GameOver,mx,my;
char str[100], str2[100], strshow1[100], strshow2[100], strshow3[100], strshow4[100], strshow5[100];
int len;
int mode;
int flag = 0;
int prflag=0;
int Boss;
int ja,ba;
char pname[100];
char nameShow[10];
//int ax,ay=screenWidth,by=screenWidth,bx,cx,cy=screenWidth;

int xxx=60,yyy=690;



//#include "movement.h"

bool jump =false;
bool jumpUp=false;

int NatsuCoordinateJump= 0;

int standcounter=0;
int eee;
int enemyPassedCounter=0;
int life=0;
int bosslife=0;
int point=0;
int by= 9;
int bb1,bb2;
int backfire;
int counterhit=0;


/*
struct player
{
	int score;
	char name[250];
}play[100],t;
*/

//structure for inputing name and scores
struct Player {
	char player_name [30];
	int score;

    Player(){
		strcpy(player_name, "Arman");
		score = 0;
	}

	
	Player(char* pn, int _score)
	  {
		strcpy(player_name,pn);
		score = _score;
	  }

	Player(char* pn1)
	  {
		strcpy(player_name,pn1);
		score = 0;
	  }

	char* getPlayerName(){
		return player_name;
	}

	void setPlayerName(char* _player_name){
		strcpy(player_name, _player_name);
	}

	int getScore(){
		return score;
	}

	void setScore(int _score){
		score = _score;
	}

};

Player winner[10];



void read()
{
	//reading name and scores from the text file
	FILE *fp = fopen("data.txt", "r");
	for(int i=0; i<5; i++){
		char s[30];
		int sc;
		fscanf(fp, "%s %d", s, &sc);
		winner[i].setPlayerName(s);//putiing name in structure type array
		winner[i].setScore(sc);////putiing score in structure type array
	}
	winner[5].setPlayerName(pname);
		winner[5].setScore(point);

	fclose(fp);
	int temp;
	
	//bubble sorting the score in higher order
	for(int i=0; i<6; i++){
		for(int j=i+1; j<6; j++){
			if(winner[i].getScore() <winner[j].getScore()){
				/*swap(topPlayers[j].score ,topPlayers[j+1].score );
				swap(topPlayers[j].player_name ,topPlayers[j+1].player_name);*/

				temp = winner[i].score ;
				winner[i].score = winner[j].score ;
				winner[j].score = temp;

				strcpy(nameShow, winner[i].player_name);
				strcpy(winner[i].player_name, winner[j].player_name);
				strcpy(winner[j].player_name, nameShow);

			}
		}
	}
	
 


}
//showing name and score in the games score page
void showable(){


	
	sprintf(nameShow, "%s", winner[0].getPlayerName());//will take playes name from winner array to s
		iText(158, 350,nameShow, GLUT_BITMAP_TIMES_ROMAN_24);//will show players name in score page

		sprintf(nameShow, "%d", winner[0].getScore());
		iText(700, 350,nameShow, GLUT_BITMAP_TIMES_ROMAN_24);



	sprintf(nameShow, "%s", winner[1].getPlayerName());
		iText(158, 310, nameShow, GLUT_BITMAP_TIMES_ROMAN_24);

		sprintf(nameShow, "%d", winner[1].getScore());
		iText(700, 310,nameShow, GLUT_BITMAP_TIMES_ROMAN_24);

	sprintf(nameShow, "%s", winner[2].getPlayerName());
		iText(158, 270, nameShow, GLUT_BITMAP_TIMES_ROMAN_24);

		sprintf(nameShow, "%d", winner[2].getScore());
		iText(700, 270,nameShow, GLUT_BITMAP_TIMES_ROMAN_24);


	sprintf(nameShow, "%s", winner[3].getPlayerName());
		iText(158, 230, nameShow, GLUT_BITMAP_TIMES_ROMAN_24);

		sprintf(nameShow, "%d", winner[3].getScore());
		iText(700, 230,nameShow, GLUT_BITMAP_TIMES_ROMAN_24);



	sprintf(nameShow, "%s", winner[4].getPlayerName());
		iText(158, 190, nameShow, GLUT_BITMAP_TIMES_ROMAN_24);


		sprintf(nameShow, "%d", winner[4].getScore());
		iText(700, 190,nameShow, GLUT_BITMAP_TIMES_ROMAN_24);



		sprintf(nameShow, "%s", winner[5].getPlayerName());//user input player name
		iText(158, 150, nameShow, GLUT_BITMAP_TIMES_ROMAN_24);

	    sprintf(nameShow, "%d", winner[5].getScore());//new player score
		iText(700, 150, nameShow, GLUT_BITMAP_TIMES_ROMAN_24);

}

void enemyMovement1()//1st enemy movement
{
	Lbx1-=dx;
	if(Lbx1<=0)
	{
		//enemyPassedCounter++;
		Lby1=screenWidth;
	}

}
void enemyMovement2()//2nd enemy movement
{
	Lbx2-=dx;
	if(Lbx2<=0)
	{
		//enemyPassedCounter++;
		Lbx2=screenWidth;

	}
}

void enemyMovement3()//2nd enemy movement
{

	Lbx3-=dx;
	if(Lbx3<=0)
	{
		//enemyPassedCounter++;
		Lbx3=screenWidth;

	}
}
void enemyMovement4()//4th enemy movement
{

	Lbx4-=dx;
	if(Lbx4<=0)
	{
		//enemyPassedCounter++;
		Lbx4=screenWidth;

	}
}

void enemyMovement5()//5th enemy movement
{

	Lbx5-=dx;
	if(Lbx5<=0)
	{
		//enemyPassedCounter++;
		Lbx5=screenWidth;

	}
}
void enemyMovement6()//6th enemy movement
{

	Lbx6-=dx;
	if(Lbx6<=0)
	{
		//enemyPassedCounter++;
		Lbx6=screenWidth;

	}
}
void enemyMovement7()//6th enemy movement
{

	Bbx1-=dx;
	if(Bbx1<=0)
	{
		//enemyPassedCounter++;
		Bbx1=screenWidth;

	}
}
void enemyMovement8()//6th enemy movement
{

	Bbx2-=dx;
	if(Bbx2<=0)
	{
		//enemyPassedCounter++;
		Bbx2=screenWidth;

	}
}


void fireMovement1()
{

	bx1-=by;
	if(bx1<=0)
	{
		bx1=Bbx1;

	}
	bx2-=by;
	if(bx2<=0)
	{
		bx2=Bbx2;

	}
}
void fireMovement2()
{

	bx2-=by;
	if(bx2<=0)
	{
		bx2=Bbx2;

	}
}



void playermovement()
{
	if(help)
	{
		if(jump)
		{
			if(jumpUp)
			{
			iShowBMP2(NatsuX,NatsuY+NatsuCoordinateJump,NatsuJump[ImageIndex],0);
			}
			else
			{
			iShowBMP2(NatsuX,NatsuY+NatsuCoordinateJump,NatsuJump[0],0);
			}

		}
		else
		{	
			if(!NowStand)
			{
			iShowBMP2(NatsuX,NatsuY,NatsuForward[ImageIndex],0);
			standcounter++;
			if(standcounter>=1000000000000)
			{
			standcounter=-1000;
			ImageIndex = 0;
			NowStand = true;
			}

			}
			else
			{
			iShowBMP2(NatsuX,NatsuY,NatsuForward[0],0);
		
	
			}

		}
	}

	 if(Smash)
	{
		
	
		iShowImage(NatsuX,NatsuY,200,310,smash);
		
			
		

		
	
	}
}



void collision()
{
	for(int i=0;i<100;i++)
	{
	if((fire[i].x +20> Lbx1 && fire[i].x < Lbx1+80) && (fire[i].y+ 61>Lby1 && fire[i].y <Lby1 +120))
	{
		
		Lbx1=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
		point = point+10; 
		
	

	}
	else if((fire[i].x +20> Lbx2 && fire[i].x < Lbx2+80) && (fire[i].y+ 61>Lby2 && fire[i].y <Lby2 +120))
	{
		Lbx2=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
		point = point+10;
	}
	else if((fire[i].x +20> Lbx3 && fire[i].x < Lbx3+80) && (fire[i].y+ 61>Lby3 && fire[i].y <Lby3 +120))
	{
		Lbx3=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
		point = point+10;

	}
	else if((fire[i].x +20> Lbx4 && fire[i].x < Lbx4+80) && (fire[i].y+ 61>Lby4 && fire[i].y <Lby4 +120))
	{
		Lbx4=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
		point = point+10;
	}
	else if((fire[i].x +20> Lbx5 && fire[i].x < Lbx5+80) && (fire[i].y+ 61>Lby5 && fire[i].y <Lby5 +120))
	{
		Lbx5=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
		point = point+10;
	}
	else if((fire[i].x +20> Lbx6 && fire[i].x < Lbx6+80) && (fire[i].y+ 61>Lby6 && fire[i].y <Lby6 +120))
	{
		Lbx6=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
		point = point+10;
	}
	}
	
	for(int i=0;i<100;i++)
	{
	if((Bfire[i].x +130 > Bbx1 && Bfire[i].x < Bbx1 +100) && (Bfire[i].y+ 120 >Bby1 && Bfire[i].y <Bby1 +120))
	{
		
		Bbx1=screenWidth;
		Bfire[i].x=1500;
		Bfire[i].y=1500;
		point =point+15;

	

	}
	else if((Bfire[i].x +130 > Bbx2 && Bfire[i].x < Bbx2 +100) && (Bfire[i].y+ 120 >Bby2 && Bfire[i].y <Bby2 +120))
	{
		Bbx2=screenWidth;
		Bfire[i].x=1500;
		Bfire[i].y=1500;
		point =point+15;
	}

	else if((Bfire[i].x +130 > bx1 && Bfire[i].x < bx1 +80) && (Bfire[i].y+ 120 >by1 && Bfire[i].y <by1 +120))
	{
		bx1=1400;
		by1=1400;
		Bfire[i].x=1500;
		Bfire[i].y=1500;
		point =point+5;
	}
	else if((Bfire[i].x +130 > bx2 && Bfire[i].x < bx2 +80) && (Bfire[i].y+ 120 >by2 && Bfire[i].y <by2 +120))
	{
		bx2=1400;
		by2=1400;
		Bfire[i].x=1500;
		Bfire[i].y=1500;
		point =point+5;
	}
	}
	
	if(NatsuX <=0)
	{
		NatsuX=0;
	}

	if(NatsuX >= screenWidth-150)
	{
		NatsuX=screenWidth-150;
	}

	
	if(NatsuX+ 100>Bbx1 && NatsuX<Bbx1+180 && NatsuY +210 >Bby1 && NatsuY < Bby1+320)
	{
			NatsuX=0;
			life++;
			//enemy2[i].BbirdShow=true;

	}
	else if(NatsuX+ 100>Bbx2 && NatsuX<Bbx2+180 && NatsuY +210 >Bby2 && NatsuY < Bby2+320)
	{
		NatsuX=0;
		life++;
	}

	if(NatsuX+ 50>bx1 && NatsuX<bx1+80 && NatsuY+20  >by1 && NatsuY < by1+120)
	{
		NatsuX=0;
		life++;
	}
	else if(NatsuX+ 50>bx1 && NatsuX<bx1+80 && NatsuY+20 >by1 && NatsuY < by1+120)
	{
		NatsuX=0;
		life++;
	}
	
	/*
	for(int i=0;i<100;i++)
	{
	if((fire[i].x +20>Boss_x && fire[i].x < Boss_x+350) && (fire[i].y+ 61>Boss_y && fire[i].y <Boss_y+10))
	{
		
		//Lbx1=screenWidth;
		fire[i].x=1500;
		fire[i].y=1500;
		counterhit++;
		//point = point+10; 
		
	

	}
	}
	*/



	////ending theory ///

	if(life==10)
	{
		Lby1=500,Lby2=350,Lby3=400,Lby4=600,Lby5=450,Lby6=550;
		 Lbx1=1360, Lbx2=1400, Lbx3=1600, Lbx4=1500, Lbx5=1396, Lbx6=1800;
		 Bby1=50,Bby2=50;
		 Bbx1=1360,Bbx2=2000;
		  by1=50,by2=50;
		  bx1=1360,bx2=2000;

		flag=13;
		prflag=0;
		life=0;
	}
	if(point==50)
	{
		Lby1=500,Lby2=350,Lby3=400,Lby4=600,Lby5=450,Lby6=550;
		 Lbx1=1360, Lbx2=1400, Lbx3=1600, Lbx4=1500, Lbx5=1396, Lbx6=1800;
		 Bby1=50,Bby2=50;
		 Bbx1=1360,Bbx2=2000;
		  by1=50,by2=50;
		  bx1=1360,bx2=2000;
		flag=9;
		life=0;
		
	}
	if(counterhit==10)
	{
		flag=13;

		Lby1=500,Lby2=350,Lby3=400,Lby4=600,Lby5=450,Lby6=550;
		 Lbx1=1360, Lbx2=1400, Lbx3=1600, Lbx4=1500, Lbx5=1396, Lbx6=1800;
		 Bby1=50,Bby2=50;
		 Bbx1=1360,Bbx2=2000;
		  by1=50,by2=50;
		  bx1=1360,bx2=2000;
		
		prflag=0;
		life=0;
		counterhit=0;
		iPauseTimer(bossmove);
		

	}

	//lifecollision();


	////collision ends////


}

///// life image ////
void lifeimage()
{
	iShowImage(xxx,yyy,70,100,l1);
	iShowImage(xxx+45,yyy,70,100,l2);
	iShowImage((xxx+45)+45,yyy,70,100,l3);
	iShowImage((xxx+45+45)+45,yyy,70,100,l4);
	iShowImage((xxx+45+45+45)+45,yyy,70,100,l5);
	iShowImage((xxx+45+45+45+45)+45,yyy,70,100,l6);
	iShowImage((xxx+45+45+45+45+45)+45,yyy,70,100,l7);
	iShowImage((xxx+45+45+45+45+45+45)+45,yyy,70,100,l8);
	iShowImage((xxx+45+45+45+45+45+45+45)+45,yyy,70,100,l9);
	iShowImage((xxx+45+45+45+45+45+45+45+45)+45,yyy,70,100,l10);
}
void lifecollision()
{
	if(life==1)
	{
		iShowImage(xxx,yyy,70,100,l1);
	}
	else if(life==2)
	{
		iShowImage(xxx,yyy,70,100,l1);
		iShowImage(xxx+45,yyy,70,100,l2);
	}
	else if(life==3)
	{
		iShowImage(xxx,yyy,70,100,l1);
		iShowImage(xxx+45,yyy,70,100,l2);
		iShowImage((xxx+45)+45,yyy,70,100,l3);
	}
	else if(life==4)
	{
		iShowImage(xxx,yyy,70,100,l1);
		iShowImage(xxx+45,yyy,70,100,l2);
		iShowImage((xxx+45)+45,yyy,70,100,l3);
		iShowImage((xxx+45+45)+45,yyy,70,100,l4);
	}
	else if(life==5)
	{
		iShowImage(xxx,yyy,70,100,l1);
		iShowImage(xxx+45,yyy,70,100,l2);
		iShowImage((xxx+45)+45,yyy,70,100,l3);
		iShowImage((xxx+45+45)+45,yyy,70,100,l4);
		iShowImage((xxx+45+45+45)+45,yyy,70,100,l5);
	}
	else if(life==6)
	{
		iShowImage(xxx,yyy,70,100,l1);
		iShowImage(xxx+45,yyy,70,100,l2);
		iShowImage((xxx+45)+45,yyy,70,100,l3);
		iShowImage((xxx+45+45)+45,yyy,70,100,l4);
		iShowImage((xxx+45+45+45)+45,yyy,70,100,l5);
		iShowImage((xxx+45+45+45+45)+45,yyy,70,100,l6);
	}
	else if(life==7)
	{
		iShowImage(xxx,yyy,70,100,l1);
		iShowImage(xxx+45,yyy,70,100,l2);
		iShowImage((xxx+45)+45,yyy,70,100,l3);
		iShowImage((xxx+45+45)+45,yyy,70,100,l4);
		iShowImage((xxx+45+45+45)+45,yyy,70,100,l5);
		iShowImage((xxx+45+45+45+45)+45,yyy,70,100,l6);
		iShowImage((xxx+45+45+45+45+45)+45,yyy,70,100,l7);
	}
	else if(life==8)
	{
		iShowImage(xxx,yyy,70,100,l1);
		iShowImage(xxx+45,yyy,70,100,l2);
		iShowImage((xxx+45)+45,yyy,70,100,l3);
		iShowImage((xxx+45+45)+45,yyy,70,100,l4);
		iShowImage((xxx+45+45+45)+45,yyy,70,100,l5);
		iShowImage((xxx+45+45+45+45)+45,yyy,70,100,l6);
		iShowImage((xxx+45+45+45+45+45)+45,yyy,70,100,l7);
		iShowImage((xxx+45+45+45+45+45+45)+45,yyy,70,100,l8);
	}
	else if(life==9)
	{
		iShowImage(xxx,yyy,70,100,l1);
		iShowImage(xxx+45,yyy,70,100,l2);
		iShowImage((xxx+45)+45,yyy,70,100,l3);
		iShowImage((xxx+45+45)+45,yyy,70,100,l4);
		iShowImage((xxx+45+45+45)+45,yyy,70,100,l5);
		iShowImage((xxx+45+45+45+45)+45,yyy,70,100,l6);
		iShowImage((xxx+45+45+45+45+45)+45,yyy,70,100,l7);
		iShowImage((xxx+45+45+45+45+45+45)+45,yyy,70,100,l8);
		iShowImage((xxx+45+45+45+45+45+45+45)+45,yyy,70,100,l9);
	}
	else if(life==10)
	{
		iShowImage(xxx,yyy,70,100,l1);
		iShowImage(xxx+45,yyy,70,100,l2);
		iShowImage((xxx+45)+45,yyy,70,100,l3);
		iShowImage((xxx+45+45)+45,yyy,70,100,l4);
		iShowImage((xxx+45+45+45)+45,yyy,70,100,l5);
		iShowImage((xxx+45+45+45+45)+45,yyy,70,100,l6);
		iShowImage((xxx+45+45+45+45+45)+45,yyy,70,100,l7);
		iShowImage((xxx+45+45+45+45+45+45)+45,yyy,70,100,l8);
		iShowImage((xxx+45+45+45+45+45+45+45)+45,yyy,70,100,l9);
		iShowImage((xxx+45+45+45+45+45+45+45+45)+45,yyy,70,100,l10);
	}
}




void drawTextBox()//name inputing box for scores
{
	iSetColor(150, 150, 150);
	iRectangle(50, 250, 250, 30);
}

//iDraw function
void iDraw()
{
	iClear();
	//Menu informations
	if(prflag==0)
	{
		iPauseTimer(LB1);
		iPauseTimer(LB2);
		iPauseTimer(LB3);
		iPauseTimer(LB4);
		iPauseTimer(LB5);
		iPauseTimer(LB6);
		iPauseTimer(BB1);
		iPauseTimer(BB2);
		iPauseTimer(bb1);
	}
	else if(prflag==1)
	{
		iResumeTimer(LB1);
		iResumeTimer(LB2);
		iResumeTimer(LB3);
		iResumeTimer(LB4);
		iResumeTimer(LB5);
		iResumeTimer(LB6);
		iResumeTimer(BB1);
		iResumeTimer(BB2);
		iResumeTimer(bb1);
	}
    if(flag == 0){
		prflag=0;
	iShowImage(0, 0, screenWidth, screenHeight, Menu);
	//point=0;
	}
	else if (flag == 1)
	{
		iShowImage(0, 0, screenWidth, screenHeight, Background);
		//lifeimage();
		lifecollision();

		LbirdMove();
		BbirdMove();
		fireshow();
		//iShowImage(10, 10, 150, 170, Hero);
		prflag=1;
		//point=0;
		iPauseTimer(bossmove);

		playermovement();
		/////
		

		/////
		collision();

		iShowImage(Lbx1,Lby1,80,120,LiLB1);//enemy1
		iShowImage(Lbx2,Lby2,80,120,LiLB1);//enemy2
		
		iShowImage(Lbx3,Lby3,80,120,LiLB1);//enemy3
		iShowImage(Lbx4,Lby4,80,120,LiLB1);//enemy4

		iShowImage(Lbx5,Lby5,80,120,LiLB1);//enemy5
		iShowImage(Lbx6,Lby6,80,120,LiLB1);//enemy6
	
		iShowImage(Bbx1,Bby1,320,220,BigB1);
		iShowImage(bx1-20,by1+20,50,50,bigfire);


		iShowImage(Bbx2,Bby2,320,220,BigB1);
		iShowImage(bx2-20,by2+20,50,50,bigfire);

		char scoreText[6];
		
		sprintf(scoreText,"%d",point);
		
			//iText(100,100,"press d to complete level2");
		iText(20,680,"SCORE: ",GLUT_BITMAP_HELVETICA_18);

		iText(100,680,scoreText,GLUT_BITMAP_HELVETICA_18);


		iShowImage(1100, 50, 150, 150, Back);
	}
	else if (flag == 2)
	{ 
		iShowImage(0, 0, screenWidth, screenHeight, Ins);
		iShowImage(1100, 50, 150, 150, Back);
	}
	else if (flag == 3)
	{ 

		//reading scores from file and show them on the scorecard screen
		iShowImage(0, 0, screenWidth, screenHeight, Score);
		iShowImage(1100, 50, 150, 150, Back);
		read();
		showable();
		
	}
	else if (flag == 4)
	{ 
		iShowImage(0, 0, screenWidth, screenHeight, About);
		iShowImage(1100, 50, 150, 150, Back);
	}
	else if (flag == 5)
	{ 
		iShowImage(0, 0, screenWidth, screenHeight, Credits);
		iShowImage(1100, 50, 150, 150, Back);
	}
	else if (flag == 6)
	{ 
		iShowImage(0, 0, screenWidth, screenHeight, GameOver);
		iShowImage(1100, 50, 150, 150, Back);
	
	}
	else if (flag == 7)
	{
		exit(0);
	}
	
	///// boss level /////
	else if(flag==9)
	{
		
		Lby1=500,Lby2=350,Lby3=400,Lby4=600,Lby5=450,Lby6=550;
		 Lbx1=1360, Lbx2=1400, Lbx3=1600, Lbx4=1500, Lbx5=1396, Lbx6=1800;
		 Bby1=50,Bby2=50;
		 Bbx1=1360,Bbx2=2000;
		  by1=50,by2=50;
		  bx1=1360,bx2=2000;

		prflag=0;
		iShowImage(0,0,screenWidth,screenHeight,backfire);

		iShowImage(ax,ay,120,200,f1);
		iShowImage(zx,zy,120,200,f2);
		iShowImage(cx,cy,120,200,f3);

		playermovement();



		//lifeimage();
		//collision();

	if(NatsuX+ 100>ax && NatsuX<ax+120 && NatsuY+110 >ay && NatsuY < ay+200)
	{
		
		ay=screenWidth;
		life++;
		NatsuX=0;
		point =point-5;
	}
	else if(NatsuX+ 100>zx && NatsuX<zx+120 && NatsuY+110 >zy && NatsuY < zy+200)
	{
		//zx=1500;
		zy=screenWidth;
		life++;
		NatsuX=0;
		point =point-5;

	}
	else if(NatsuX+ 100>cx && NatsuX<cx+120 && NatsuY+110 >cy && NatsuY < cy+200)
	{
		//cx=1500;
		cy=screenWidth;
		life++;
		NatsuX=0;
		point =point-5;
	}
	lifecollision();





		/////////////////

		for(int i=0;i<100;i++)
	{
	if((Bfire[i].x +130>Boss_x && Bfire[i].x < Boss_x+350) && (Bfire[i].y+ 120>Boss_y && Bfire[i].y <Boss_y+10))
	{
		
		//Lbx1=screenWidth;

		Bfire[i].x=1500;
		Bfire[i].y=1500;
		counterhit++;
		life++;
		//point = point+10; 
		
	

	}
	}




		if(NatsuX <=0)
	{
		NatsuX=0;
	}

	if(NatsuX >= screenWidth-150)
	{
		NatsuX=screenWidth-150;
	}
		//collision();
		fireshow();
		iRotate(Boss_y,Boss_x,20);
		iShowImage(Boss_x, Boss_y, 400, 200, Boss);
		iUnRotate();

		iResumeTimer(ja);
		iResumeTimer(ba);
		iResumeTimer(bossmove);


			if(counterhit==10)
	{
		flag=13;

		Lby1=500,Lby2=350,Lby3=400,Lby4=600,Lby5=450,Lby6=550;
		 Lbx1=1360, Lbx2=1400, Lbx3=1600, Lbx4=1500, Lbx5=1396, Lbx6=1800;
		 Bby1=50,Bby2=50;
		 Bbx1=1360,Bbx2=2000;
		  by1=50,by2=50;
		  bx1=1360,bx2=2000;
		
		prflag=0;
		life=0;
		counterhit=0;
		iPauseTimer(bossmove);
		

	}


		
		char scoreText[6];
		sprintf(scoreText,"%d",point);
			//iText(100,100,"press d to complete level2");
		iText(20,680,"SCORE: ",GLUT_BITMAP_HELVETICA_18);

		iText(100,680,scoreText,GLUT_BITMAP_HELVETICA_18);
	}
	else if(flag==13)
	{

		prflag=0;
		iShowImage(0, 0, screenWidth, screenHeight, GameOver);
		iShowImage(1100, 50, 150, 150, Back);
		iText(50,300,"Enter your name: ",GLUT_BITMAP_HELVETICA_18);
		drawTextBox();
		iSetColor(255, 255, 255);
		iText(55, 260, str);
	}
	
	
}

void iPassiveMouse(int x, int y)
{
;
}

void iMouseMove(int mx, int my)
{

	;

}
void iMouse(int button, int state, int mx, int my)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		printf("\n%d \t %d\n", mx, my);
		while(flag==0)
		{
		//Start button actions
		if(mx > 66 && mx < 308 && my > 310 && my < 354)
		{
			flag = 1;
			prflag=1;
		
	    }
		//Informations button actions
		else if( mx > 66 && mx < 308 && my > 255 &&  my < 297)
		{
			flag = 2;

		}
		//Score button actions
		else if( mx > 66 && mx < 308 && my > 200 &&  my < 238)
		{
			flag = 3;
		}
		//About button actions
		else if( mx > 66 && mx < 308 && my > 144 &&  my < 185)
		{
			flag = 4;
		}
		//Credits button actions
		else if( mx > 66 && mx < 308 && my > 91 &&  my < 133)
		{
			flag = 5;
		}
		//Exit button actions
		else if( mx > 66 && mx < 308 && my > 33 &&  my < 76)
		{
			flag = 7;
		}
		}
		//Back button actions
		
		
	if( mx > 1110 && mx < 1242 && my > 91 &&  my < 162)
		{
			flag = 0;

		}
		
		//clicking the left mouse button to the name taking box to input the name
	 if(mx > 529 && mx < 778 && my > 554 && my < 580)
		{
			mode = 1;
		}
		else if(mx > 529 && mx < 778 && my > 501 && my < 530)
		{
			mode = 2;
		}

		
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
	
	
	}
}
}
void iKeyboard(unsigned char key)
{

	if (key == 'v')
	{

		if(ImageIndex >=5 )
		{
			ImageIndex++;
			ImageIndex=0;
		}
		if(ImageIndex ==5 )
		{
			ImageIndex =5;
			if(ImageIndex >=0 )
		{
			ImageIndex--;
			
		}
		}
		NowFire =true;
		
	}

	if (key == ' ')
	{
		if(!jump)
		{
			jump=true;
			jumpUp=true;
		}
		help=true;
		Smash=false;
	}

	if (key == 'a')
	{
		NatsuX -=10;
			ImageIndex++;

		if(ImageIndex >=6 )
			ImageIndex=0;

		

		NowStand = false;
		help=true;
		Smash=false;
	}

	if (key == 'd')
	{
			/// going right ////////
			NatsuX +=10;
			ImageIndex++;

		if(ImageIndex >=6 )
			ImageIndex=0;
		

		NowStand = false;
		help=true;
		Smash=false;
	}

	///// using power ///

	if (key == 'f')
	{
		if(Firecount <100)
		{
			Firecount++;

		}
		else if(Firecount == 100)
		{
			Firecount=0;
		}

		fire[Firecount-1].show =true;
		fire[Firecount-1].x=NatsuX+57;
		fire[Firecount-1].y=NatsuY+127;
		Smash=false;
		help=true;

	}

	if(key=='c'&& keypressed)
	{
		if(Bfirecount <20)
		{
			Bfirecount ++;
			

		}
		else if(Bfirecount == 20)
		{
				Bfire[Bfirecount-1].show =false;
				keypressed=0;
		}
		

		Smash=true;
		help=false;
		NowStand=true;
		jump=true;
		Bfire[Bfirecount-1].show =true;
		Bfire[Bfirecount-1].x=NatsuX+50;
		Bfire[Bfirecount-1].y=NatsuY+screenHeight ;

	}

	 if(flag==13)
  {
	  if(key == '\r')//if enter is pressed after giving a name in testbox it come back to the menu page
		{
			
			strcpy(pname, str);
			printf("%s\n", str2);
			for(int i = 0; i < len; i++)
				str[i] = 0;
			flag = 0;
			len = 0;

		
		}
		else
		{
			str[len] = key;
			len++;
		}
  }


	
	}



void iSpecialKeyboard(unsigned char key)
{
  while (flag == 1){
   
	if (key == GLUT_KEY_END)
	{	
	
	{
		flag = 6;
		}
	}
  } 

 
}





////// functions /////

void Natsujump()
{
	if(jump)
	{
		if(jumpUp)
		{
			NatsuCoordinateJump +=5;
			if(NatsuCoordinateJump >=JumpLimit)
			{
				jumpUp =false;
			}
		}
		else
		{
			NatsuCoordinateJump -=5;
			if(NatsuCoordinateJump <0 )
			{
				jump =false;
			NatsuCoordinateJump =0;
			}

		}
	}
	

	
}

////// LBird moving /////

void EnemyBirdSpeed()
{
	for(int i=0;i<LbirdsNumber;i++)
	{
		enemy[i].LbirdX -=10;
		if(enemy[i].LbirdX <=0 )
		{
			enemy[i].LbirdX = screenWidth + rand()%800;
			//enemy[i].LbirdShow = true;
		}
		enemy[i].LbirdIndex++;
		if(enemy[i].LbirdIndex >=3)
		{
			enemy[i].LbirdIndex = 0;
		}
	}
	
}

//// BBird moving ////

void EnemyBird2Speed()
{
	for(int i=0;i<BbirdsNumber;i++)
	{
		enemy2[i].BbirdX -=10;
		if(enemy2[i].BbirdX <=0 )
		{
			enemy2[i].BbirdX = screenWidth + rand()%1000;
			//enemy2[i].BbirdShow = true;
		}
		enemy2[i].BbirdIndex++;
		if(enemy2[i].BbirdIndex >=3)
		{
			enemy2[i].BbirdIndex = 0;
		}
	}


}



void setLBird()
{
	for(int i =0;i<LbirdsNumber;i++)
	{
		enemy[i].LbirdX = screenWidth + rand()%800;
		enemy[i].LbirdY = 200 + rand()%500;
		enemy[i].LbirdIndex = rand()%10;
		enemy[i].LbirdShow = true;

	}
}

void setBBird()
{
	for(int i =0;i<BbirdsNumber;i++)
	{
		enemy2[i].BbirdX = screenWidth + rand()%1000;
		enemy2[i].BbirdY = 30;
		enemy2[i].BbirdIndex = rand()%10;
		enemy2[i].BbirdShow = true;

	}
}
//////Fire /////
void FireThrow()
{
	for(int i=0;i<Firecount;i++)
	{
		if(fire[i].show)
		{
			fire[i].x +=20;
			/////sdsdsds///
			fire[i].y +=10;

		}
		
		if(fire[i].x > screenWidth)
		{
			fire[i].show =false;
		}
		
	}
	for(int i=0;i<Bfirecount;i++)
	{
		if(Bfire[i].show)
		{
			Bfire[i].y -=20;
		}
		if(Bfire[i].x > screenHeight)
		{
			Bfire[i].show =false;
		}
	}
	


}

//imain function
int main()
{
	read();



	setLBird();
	setBBird();

	ja=iSetTimer(12,Natsujump);
	//iSetTimer(80,EnemyBirdSpeed);
	//iSetTimer(110,EnemyBird2Speed);
	ba=iSetTimer(20,FireThrow);
	//iSetTimer(20,setBBird);

	/// enemy movement timing ////
	LB1 = iSetTimer(58,enemyMovement1);
	LB4 = iSetTimer(50,enemyMovement4);
	//LB6= iSetTimer(60,enemyMovement6);
	//LB5 = iSetTimer(70,enemyMovement5);
	bossmove=iSetTimer(20,bossmovement);
	LB2 = iSetTimer(47,enemyMovement2);
	LB3 =iSetTimer(85,enemyMovement3);
	BB1=iSetTimer(70,enemyMovement7);
	BB2=iSetTimer(85,enemyMovement8);
	////fire movement ////
	bb1 = iSetTimer(70,fireMovement1);
	//bb2 = iSetTimer(30,fireMovement2);

	iInitialize(screenWidth, screenHeight, "The Last FireBender");

	
	//Images implimantations
	Menu = iLoadImage("images\\1Menunew.png");
	Background = iLoadImage("images\\1Background.jpg");
	Back = iLoadImage("images\\Back.png");
	Ins = iLoadImage("images\\3Instructions.png");
	Score = iLoadImage("images\\Scoreboard.png");
	Hero = iLoadImage("images\\0.png");
	Boss = iLoadImage("images\\RedDragon1.png");
	About = iLoadImage("images\\About.png");
	Credits = iLoadImage("images\\Credits.png");
	GameOver = iLoadImage("images\\Gameover.jpg");
	backfire=iLoadImage("images\\fireback.png");

	imageload();

	iStart();

	return 0;
}

